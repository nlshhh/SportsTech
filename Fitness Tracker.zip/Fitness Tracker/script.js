function calculateProtein() {
  // Get the user's input values
  const weight = document.getElementById("weight").value;
  const activityLevel = document.getElementById("activity-level").value;

  // Validate input
  if (!weight || weight <= 0 || !activityLevel) {
    alert("Please enter valid weight and select activity level.");
    return;
  }

  let proteinPerKg;

  // Determine protein needs based on activity level
  switch (activityLevel) {
    case "sedentary":
      proteinPerKg = 1.2; // 1.2g of protein per kg for sedentary
      break;
    case "active":
      proteinPerKg = 1.5; // 1.5g of protein per kg for active
      break;
    case "very-active":
      proteinPerKg = 2.0; // 2.0g of protein per kg for very active
      break;
    default:
      proteinPerKg = 1.2;
  }

  // Calculate protein intake
  const proteinIntake = (weight * proteinPerKg).toFixed(2);

  // Display the result
  const resultText = `For your weight of ${weight} kg and activity level "${activityLevel}", your recommended daily protein intake is: <strong>${proteinIntake} grams</strong> of protein.`;
  document.getElementById("protein-result").innerHTML = resultText;
}
// Water Tracker
let totalIntake = 0;
function updateWaterProgress() {
  let goal = parseFloat(document.getElementById("goal").value);
  let intake = parseFloat(document.getElementById("intake").value);

  if (isNaN(goal) || isNaN(intake) || goal <= 0 || intake < 0) {
    alert("Please enter valid values for both goal and intake.");
    return;
  }

  totalIntake += intake; //  accumulate intake
    let progress = (totalIntake / goal) * 100;
    progress = progress > 100 ? 100 : progress;  // Limit to 100%

  document.getElementById("water-progress").style.width = progress + "%";
  if (totalIntake >= goal) {
      document.getElementById("water-progress-text").innerText = "🎉 Target Completed!";
    } else {
      document.getElementById("water-progress-text").innerText = progress.toFixed(2) + "% - Keep Going!";
    }
  document.getElementById("intake").value = "";
}

// Calorie Analyzer - Calculate BMR and TDEE
function calculateCalories() {
  // Get user inputs
  const age = parseInt(document.getElementById("age").value);
  const gender = document.getElementById("gender").value;
  const weight = parseFloat(document.getElementById("weight").value);
  const height = parseFloat(document.getElementById("height").value);
  const activityLevel = parseFloat(document.getElementById("activity").value);

  // Check for valid inputs
  if (isNaN(age) || age <= 0 || isNaN(weight) || weight <= 0 || isNaN(height) || height <= 0) {
    alert("Please enter valid values for age, weight, and height.");
    return;
  }

  let bmr;

  // Harris-Benedict Formula for BMR calculation
  if (gender === "male") {
    bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age); // For male
  } else {
    bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age); // For female
  }

  // Calculate TDEE based on activity level
  const tdee = bmr * activityLevel;

  // Display the results
  document.getElementById("bmr-amount").innerText = bmr.toFixed(2);
  document.getElementById("tdee-amount").innerText = tdee.toFixed(2);
}
